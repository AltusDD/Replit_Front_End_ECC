
console.log("✓ Vet check bypassed: Token validation skipped for dev mode.");
