/* eslint-disable */
import React, { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";

/** Simple nav model – adjust routes/labels if you need to add more pages */
type Leaf = { label: string; to: string };
type Group = { title: string; items: Leaf[] };

const NAV: Group[] = [
  { title: "Dashboard", items: [{ label: "Home", to: "/dashboard" }] },

  {
    title: "Portfolio V3",
    items: [
      { label: "Properties", to: "/portfolio/properties" },
      { label: "Units", to: "/portfolio/units" },
      { label: "Leases", to: "/portfolio/leases" },
      { label: "Tenants", to: "/portfolio/tenants" },
      { label: "Owners", to: "/portfolio/owners" },
    ],
  },

  {
    title: "Cards",
    items: [
      { label: "Overview", to: "/cards/overview" },
      { label: "Delinquencies", to: "/cards/delinquencies" },
      { label: "Vacancy", to: "/cards/vacancy" },
      { label: "Turnover", to: "/cards/turnover" },
      { label: "Work Orders", to: "/cards/work-orders" },
    ],
  },

  {
    title: "Operations",
    items: [
      { label: "Accounting", to: "/ops/accounting" },
      { label: "Leasing", to: "/ops/leasing" },
      { label: "Maintenance", to: "/ops/maintenance" },
      { label: "Marketing", to: "/ops/marketing" },
    ],
  },

  {
    title: "AI Intelligence",
    items: [
      { label: "Insights", to: "/ai/insights" },
      { label: "Anomalies", to: "/ai/anomalies" },
      { label: "Recommendations", to: "/ai/recommendations" },
      { label: "Forecasts", to: "/ai/forecasts" },
    ],
  },

  {
    title: "Work Management",
    items: [
      { label: "Work", to: "/work" },
      { label: "Tasks", to: "/work/tasks" },
      { label: "Projects", to: "/work/projects" },
    ],
  },
];

export default function Sidebar() {
  const loc = useLocation();

  // collapsed state with persistence
  const [collapsed, setCollapsed] = useState<boolean>(() => {
    try {
      return localStorage.getItem("nav:collapsed") === "1";
    } catch {
      return false;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem("nav:collapsed", collapsed ? "1" : "0");
    } catch {}
    document.body.classList.toggle("sidebar-collapsed", collapsed);
  }, [collapsed]);

  const isActive = (to: string) =>
    loc.pathname === to ||
    (to !== "/dashboard" && loc.pathname.startsWith(to));

  return (
    <aside
      className={"sidebar" + (collapsed ? " collapsed" : "")}
      data-role="sidebar"
    >
      {/* Brand/logo block (your CSS targets .brand & .brand-logo) */}
      <div className="brand">
        <img className="brand-logo" src="/logo.png" alt="" />
      </div>

      {/* Independent scroll area; scrollbar hidden by CSS */}
      <div className="sidebar-scroll">
        <div role="navigation" data-nav>
          {NAV.map((group) => (
            <div className="group" key={group.title}>
              <div className="section-title">{group.title}</div>

              <div className="leafList">
                {group.items.map((item) => (
                  <Link
                    key={item.to}
                    to={item.to}
                    className={"leaf" + (isActive(item.to) ? " active" : "")}
                    data-current={isActive(item.to) ? "true" : "false"}
                  >
                    <span className="icon" aria-hidden="true" />
                    <span className="lbl">{item.label}</span>
                  </Link>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Footer actions */}
      <div className="sidebar-footer">
        <button
          className="pinBtn"
          onClick={() => setCollapsed((c) => !c)}
          aria-pressed={collapsed ? "true" : "false"}
        >
          {collapsed ? "Unpin" : "Pin"}
        </button>
      </div>
    </aside>
  );
}
