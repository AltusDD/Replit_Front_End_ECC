export default function ApiProbe(){
  return (
    <>
      <h1 className="pageTitle">Contract Probe</h1>
      <div className="panel" style={{padding:12}}>Probe page ready.</div>
    </>
  );
}
