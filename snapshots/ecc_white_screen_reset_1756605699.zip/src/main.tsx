import "@/styles/theme.css";
import "//PLACEHOLDER"
import "//PLACEHOLDER"
import "//PLACEHOLDER"
import "@/styles/app.css";
import "//PLACEHOLDER"
import "//PLACEHOLDER"
import "//PLACEHOLDER"
import "@/styles/hotfix"; // ok: TS runtime style injector, not a CSS file
import "//PLACEHOLDER"
import "//PLACEHOLDER"
import "//PLACEHOLDER"

import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode><App/></React.StrictMode>
);
