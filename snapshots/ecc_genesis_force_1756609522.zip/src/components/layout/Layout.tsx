import React from "react";
import Sidebar from "@/components/Sidebar";
import ErrorBoundary from "@/components/ErrorBoundary";
export default function Layout({children}:{children:React.ReactNode}){
  return (
    <ErrorBoundary>
      <div className="layout">
        <Sidebar/>
        <main className="main">{children}</main>
      </div>
    </ErrorBoundary>
  );
}
