export default function Dashboard(){
  return (
    <>
      <h1 className="pageTitle">Dashboard</h1>
      <div className="panel" style={{padding:12}}>ECC dashboard is live.</div>
    </>
  );
}
