import "@/styles/theme.css";
import "@/styles/app.css";
import "@/debug/crash-overlay";

import React from "react";
import ReactDOM from "react-dom/client";
import App from "@/App";

if (typeof document !== "undefined") {
  document.documentElement.setAttribute("data-theme", "altus");
}
console.log("[ECC] main.tsx boot");
ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode><App/></React.StrictMode>
);
