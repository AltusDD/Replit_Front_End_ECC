import React,{useEffect,useState} from "react";
import { Link, useLocation } from "wouter";
import NAV from "@/components/layout/navConfig";
import {
  Home, LayoutDashboard, Building2, Layers, KeyRound, Users, User,
  FileText, Calculator, TrendingUp, Wrench, Database, PieChart, Bot, Gavel,
  ClipboardList, FolderKanban, ListChecks, Repeat2, ClipboardCheck, Megaphone,
  Store, ChevronDown, ChevronRight
} from "lucide-react";

type Leaf = { label:string; path:string };
type Group = { label:string; items:Leaf[] };
type Section = { label:string; groups:Group[] };

const mapIcon = (label:string) => {
  const k = label.toLowerCase().replace(/\s+/g,"");
  return (
    k==="home" || k==="dashboard" ? Home :
    k==="portfolio" ? LayoutDashboard :
    k==="properties" ? Building2 :
    k==="units" ? Layers :
    k==="leases" ? KeyRound :
    k==="tenants" ? Users :
    k==="owners" ? User :
    k==="cards" || k==="documents" ? FileText :
    k==="accounting" ? Calculator :
    k==="marketing" ? TrendingUp :
    k==="tools" || k==="probe" ? Wrench :
    k==="data" ? Database :
    k==="analytics" ? PieChart :
    k==="ai" || k==="aiintelligence" || k==="insights" ? Bot :
    k==="legal" || k==="compliance" ? Gavel :
    k==="tasks" ? ClipboardList :
    k==="projects" ? FolderKanban :
    k==="sprints" ? Repeat2 :
    k==="backlog" ? ListChecks :
    k==="workorders" || k==="work-orders" ? ClipboardCheck :
    k==="listings" || k==="leads" || k==="campaigns" ? Megaphone :
    k==="vendors" || k==="banking" || k==="store" ? Store :
    FileText
  );
};

export default function Sidebar(){
  const [loc] = useLocation();
  const [collapsed,setCollapsed] = useState<boolean>(()=>{ try{return localStorage.getItem("nav:collapsed")==="1"}catch{return false}});
  useEffect(()=>{ try{localStorage.setItem("nav:collapsed",collapsed?"1":"0")}catch{} },[collapsed]);

  const [open,setOpen] = useState<Record<string,boolean>>(()=>{ try{return JSON.parse(localStorage.getItem("nav:open")||"{}")}catch{return{}}});
  useEffect(()=>{ try{localStorage.setItem("nav:open",JSON.stringify(open))}catch{} },[open]);

  const toggle=(key:string)=>setOpen(s=>({...s,[key]:!s[key]}));

  return (
    <aside className={`sidebar ${collapsed?"collapsed":""}`}>
      <div className="brand">
        {/* Show the brand image both expanded and collapsed */}
        <img className="brand-logo" src="/logo.png" alt="Altus Realty Group"
             onError={(e)=>{ (e.currentTarget as HTMLImageElement).style.opacity="0.85"; }} />
        <button className="pinBtn" onClick={()=>setCollapsed(!collapsed)} aria-label={collapsed?"Unpin":"Pin"}>
          {collapsed?"»":"«"}
        </button>
      </div>

      <nav>
        {(NAV as Section[]).map((section)=>(
          <div key={section.label}>
            <div className="section-title">{section.label}</div>
            {section.groups.map((g)=>{
              const key = `${section.label}/${g.label}`;
              const hasChildren = (g.items?.length||0) > 0;
              const groupHasActiveChild = hasChildren && g.items.some(it => loc === it.path || loc.startsWith(it.path+"/"));
              const isOpen = !!open[key]; // do NOT auto-open; respect saved state

              const GroupIcon = mapIcon(g.label);
              return (
                <div key={key}>
                  <button
                    className="nav-item"
                    data-current-child={groupHasActiveChild ? "true" : undefined}
                    onClick={()=> hasChildren && toggle(key)}
                    aria-expanded={hasChildren?String(isOpen):undefined}
                  >
                    <GroupIcon className="icon" size={18}/>
                    <span className="label">{g.label}</span>
                    {hasChildren ? <span className="expand">{isOpen ? <ChevronDown size={14}/> : <ChevronRight size={14}/>}</span> : null}
                  </button>

                  {hasChildren && isOpen && (
                    <div>
                      {g.items.map((leaf:Leaf)=>{
                        const active = loc === leaf.path;
                        const LeafIcon = mapIcon(leaf.label);
                        return (
                          <Link href={leaf.path} key={leaf.path}>
                            <a className={`nav-item ${active?"active":""}`}>
                              <LeafIcon className="icon" size={18}/>
                              <span className="label">{leaf.label}</span>
                            </a>
                          </Link>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ))}
      </nav>

      <div className="sidebar-footer">
        <button className="pinBtn" onClick={()=>setCollapsed(!collapsed)}>{collapsed?"Unpin":"Pin"}</button>
      </div>
    </aside>
  );
}
