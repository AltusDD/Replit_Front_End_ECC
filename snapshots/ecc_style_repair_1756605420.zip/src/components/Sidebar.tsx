import React, { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import NAV, { Section, Group, Leaf } from "@/components/layout/navConfig";

export default function Sidebar(){
  const [loc] = useLocation();
  const [collapsed,setCollapsed]=useState<boolean>(()=>{ try{return localStorage.getItem("nav:collapsed")==="1"}catch{return false}});
  useEffect(()=>{ try{localStorage.setItem("nav:collapsed",collapsed?"1":"0")}catch{} },[collapsed]);

  const [open,setOpen]=useState<Record<string,boolean>>(()=>{ try{return JSON.parse(localStorage.getItem("nav:open")||"{}")}catch{return{}}});
  useEffect(()=>{ try{localStorage.setItem("nav:open",JSON.stringify(open))}catch{} },[open]);
  const toggle=(k:string)=>setOpen(s=>({...s,[k]:!s[k]}));

  console.log("ECC Sidebar mount", { collapsed, groups: Object.keys(open).length, navSections: NAV.length });

  return (
    <aside className={`sidebar ${collapsed?"collapsed":""}`}>
      <div className="brand">
        <div className="logo"><img src="/logo.png" alt="Altus"/></div>
        <div className="title">Empire Command Center</div>
        <button className="pinBtn" onClick={()=>setCollapsed(!collapsed)}>{collapsed?"»":"«"}</button>
      </div>
      <nav className="nav">
        {NAV.map((section:Section)=>(
          <div className="section" key={section.label}>
            <div className="group-label">{section.label}</div>
            {section.groups.map((g:Group)=>{
              const key=`${section.label}/${g.label}`;
              const has=g.items?.length>0;
              const isOpen=!!open[key] || !has; // open empty groups by default
              return (
                <div className="group" key={key}>
                  <button className="group-row" onClick={()=> has && toggle(key)}>
                    <span className="icon">★</span><span className="lbl">{g.label}</span>
                    {has ? <span className="expand">{isOpen?"▾":"▸"}</span> : null}
                  </button>
                  {has && isOpen && (
                    <div className="leafList">
                      {g.items.map((leaf:Leaf)=>{
                        const active=loc===leaf.path;
                        return (
                          <Link href={leaf.path} key={leaf.path}>
                            <a className={`leaf ${active?"active":""}`} aria-current={active?"page":undefined}>
                              <span className="icon">•</span><span className="lbl">{leaf.label}</span>
                            </a>
                          </Link>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ))}
      </nav>
      <div className="sidebar-footer">
        <button className="pinBtn" onClick={()=>setCollapsed(!collapsed)}>{collapsed?"Unpin":"Pin"}</button>
      </div>
    </aside>
  );
}
