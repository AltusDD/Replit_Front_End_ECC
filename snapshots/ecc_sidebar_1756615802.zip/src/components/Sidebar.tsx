import React, { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import NAV from "@/components/layout/navConfig";
import {
  Home, LayoutDashboard, Building2, Layers, KeyRound, Users, User,
  FileText, Calculator, TrendingUp, Wrench, PieChart, Bot, Gavel,
  ClipboardList, FolderKanban, ListChecks, Repeat2, ClipboardCheck, Megaphone,
  ChevronDown, ChevronRight
} from "lucide-react";

const iconFor = (label: string) => {
  const k = (label || "").toLowerCase().replace(/\s+/g, "");
  return (
    k==="home"||k==="dashboard"?Home:
    k==="portfolio"?LayoutDashboard:
    k==="properties"?Building2:
    k==="units"?Layers:
    k==="leases"?KeyRound:
    k==="tenants"?Users:
    k==="owners"?User:
    k==="cards"?FileText:
    k==="accounting"?Calculator:
    k==="marketing"?TrendingUp:
    k==="tools"||k==="probe"?Wrench:
    k==="analytics"?PieChart:
    k==="ai"||k==="aiintelligence"?Bot:
    k==="legal"?Gavel:
    k==="tasks"?ClipboardList:
    k==="projects"?FolderKanban:
    k==="sprints"?Repeat2:
    k==="backlog"?ListChecks:
    k==="workorders"||k==="work-orders"?ClipboardCheck:
    k==="campaigns"?Megaphone:
    FileText
  );
};

export default function Sidebar(){
  const [loc] = useLocation();

  const [collapsed, setCollapsed] = useState<boolean>(() => {
    try { return localStorage.getItem("nav:collapsed")==="1"; } catch { return false; }
  });
  useEffect(()=>{ try { localStorage.setItem("nav:collapsed", collapsed?"1":"0"); } catch {} },[collapsed]);

  const [open, setOpen] = useState<Record<string, boolean>>(() => {
    try { return JSON.parse(localStorage.getItem("nav:open")||"{}"); } catch { return {}; }
  });
  useEffect(()=>{ try { localStorage.setItem("nav:open", JSON.stringify(open)); } catch {} },[open]);
  const toggle = (k:string) => setOpen(s => ({...s, [k]: !s[k]}));

  return (
    <aside className={`sidebar ${collapsed ? "collapsed" : ""}`} data-role="sidebar">
      <div className="brand">
        <div className="logo">
          <img src="/logo.png" alt="Altus Realty Group" />
        </div>
        <button
          className="pinBtn"
          onClick={()=>setCollapsed(!collapsed)}
          aria-label={collapsed ? "Unpin sidebar" : "Pin sidebar"}
          title={collapsed ? "Unpin" : "Pin"}
        >
          {collapsed ? "»" : "«"}
        </button>
      </div>

      <div className="sidebar-scroll">
        <nav className="nav" role="navigation" data-nav>
          {Array.isArray(NAV) && NAV.map((section:any) => (
            <div className="section" key={section.label}>
              {section.label ? <div className="group-label">{section.label}</div> : null}

              {Array.isArray(section.groups) && section.groups.map((g:any) => {
                const key = `${section.label}/${g.label}`;
                const hasChildren = Array.isArray(g.items) && g.items.length>0;

                const groupHasActiveChild = !!(hasChildren && g.items.some((it:any) => {
                  return loc === it.path || (typeof it.path==="string" && loc.startsWith(it.path + "/"));
                }));

                const isOpen = !!open[key];
                const showChildren = hasChildren && (isOpen || (collapsed && groupHasActiveChild));

                const GroupIcon = iconFor(g.label);

                return (
                  <div className="group" key={key}>
                    <button
                      className="group-row"
                      onClick={()=> hasChildren && toggle(key)}
                      aria-expanded={hasChildren ? String(isOpen) : undefined}
                      data-current-child={groupHasActiveChild ? "true" : undefined}
                    >
                      <GroupIcon size={16} className="icon" />
                      <span className="lbl">{g.label}</span>
                      {hasChildren ? (
                        <span className="expand">{isOpen ? <ChevronDown size={14}/> : <ChevronRight size={14}/>}</span>
                      ) : null}
                    </button>

                    {hasChildren && (
                      <ul className="leafList" style={{ display: showChildren ? "flex" : undefined, flexDirection: showChildren ? "column" : undefined, gap: showChildren ? 4 : undefined }}>
                        {g.items.map((leaf:any) => {
                          const active = loc === leaf.path;
                          const LeafIcon = iconFor(leaf.label);
                          return (
                            <li key={leaf.path}>
                              <Link href={leaf.path}>
                                <a className={`leaf ${active ? "active" : ""}`} aria-current={active ? "page" : undefined}>
                                  <LeafIcon size={14} className="icon" />
                                  <span className="lbl">{leaf.label}</span>
                                </a>
                              </Link>
                            </li>
                          );
                        })}
                      </ul>
                    )}
                  </div>
                );
              })}
            </div>
          ))}
        </nav>
      </div>

      <div className="sidebar-footer">
        {!collapsed && (
          <button className="pinBtn" onClick={()=>setCollapsed(!collapsed)}>
            {collapsed ? "Unpin" : "Pin"}
          </button>
        )}
      </div>
    </aside>
  );
}
