import React,{useEffect,useState} from "react";
import { Link, useLocation } from "wouter";
import NAV,{Section,Group,Leaf} from "@/components/layout/navConfig";
import {
  Home, LayoutDashboard, Building2, Layers, KeyRound, Users, User,
  FileText, Calculator, TrendingUp, Wrench, PieChart, Bot, Gavel,
  ClipboardList, FolderKanban, ListChecks, Repeat2, ClipboardCheck, Megaphone,
  ChevronDown, ChevronRight
} from "lucide-react";

const mapIcon=(label:string)=>{
  const k=label.toLowerCase().replace(/\s+/g,"");
  return (
    k==="home"||k==="dashboard"?Home:
    k==="portfolio"?LayoutDashboard:
    k==="properties"?Building2:
    k==="units"?Layers:
    k==="leases"?KeyRound:
    k==="tenants"?Users:
    k==="owners"?User:
    k==="cards"?FileText:
    k==="accounting"?Calculator:
    k==="marketing"?TrendingUp:
    k==="tools"||k==="probe"?Wrench:
    k==="analytics"?PieChart:
    k==="ai"||k==="aiintelligence"?Bot:
    k==="legal"?Gavel:
    k==="tasks"?ClipboardList:
    k==="projects"?FolderKanban:
    k==="sprints"?Repeat2:
    k==="backlog"?ListChecks:
    k==="workorders"||k==="work-orders"?ClipboardCheck:
    k==="campaigns"?Megaphone:
    FileText
  );
};

export default function Sidebar(){
  const [loc] = useLocation();
  const [collapsed,setCollapsed]=useState<boolean>(()=>{try{return localStorage.getItem("nav:collapsed")==="1"}catch{return false}});
  useEffect(()=>{try{localStorage.setItem("nav:collapsed",collapsed?"1":"0")}catch{}},[collapsed]);

  const [open,setOpen]=useState<Record<string,boolean>>(()=>{try{return JSON.parse(localStorage.getItem("nav:open")||"{}")}catch{return{}}});
  useEffect(()=>{try{localStorage.setItem("nav:open",JSON.stringify(open))}catch{}},[open]);
  const toggle=(k:string)=>setOpen(s=>({...s,[k]:!s[k]}));

  return (
    <aside className={`sidebar ${collapsed?"collapsed":""}`}>
      <div className="brand">
        <div className="logo">
          <img src="/logo.png" alt="Altus Realty Group"/>
        </div>
        <button className="pinBtn" onClick={()=>setCollapsed(!collapsed)} aria-label={collapsed?"Unpin":"Pin"}>
          {collapsed?"»":"«"}
        </button>
      </div>

      <nav className="nav ecc-nav" role="navigation" data-nav>
        {(NAV as Section[]).map((section)=>(
          <div className="section" key={section.label}>
            <div className="group-label">{section.label}</div>

            {section.groups.map((g:Group)=>{
              const key=`${section.label}/${g.label}`;
              const has=g.items?.length>0;
              const groupHasActiveChild = has && g.items.some(it=> loc===it.path || loc.startsWith(it.path+"/"));
              const isOpen = !!open[key];
      const showChildren = isOpen || (collapsed && groupHasActiveChild); // default closed; user controls

              const GroupIcon = mapIcon(g.label);
              return (
                <div className="group" key={key}>
                  <button
                    className="group-row"
                    data-current-child={groupHasActiveChild ? "true" : undefined}
                    onClick={()=> has && toggle(key)}
                    aria-expanded={has?String(isOpen):undefined}
                  >
                    <GroupIcon size={16} className="icon"/>
                    <span className="lbl">{g.label}</span>
                    {has ? <span className="expand">{isOpen?<ChevronDown size={14}/>:<ChevronRight size={14}/>}</span> : null}
                  </button>

                  {has && showChildren && (
                    <div className="leafList">
                      {g.items.map((leaf:Leaf)=>{
                        const active = loc===leaf.path;
                        const LeafIcon = mapIcon(leaf.label);
                        return (
                          <Link href={leaf.path} key={leaf.path}>
                            <a className={`leaf ${active?"active":""}`} aria-current={active?"page":undefined}>
                              <LeafIcon size={14} className="icon"/>
                              <span className="lbl">{leaf.label}</span>
                            </a>
                          </Link>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ))}
      </nav>

      <div className="sidebar-footer">
        <button className="pinBtn" onClick={()=>setCollapsed(!collapsed)}>{collapsed?"Unpin":"Pin"}</button>
      </div>
    </aside>
  );
}
