import React, { useEffect, useMemo, useState } from "react";
import { Link, useLocation } from "wouter";
import NAV, { Section, Group, Leaf } from "@/lib/navConfig";
import {
  Home, Building2, Layers, KeyRound, Users, User, Settings, Folder,
  FileText, Calculator, TrendingUp, Database, PieChart, Zap, Wrench,
  ChevronDown, ChevronRight
} from "lucide-react";

const iconMap: Record<string, any> = {
  dashboard: Home, home: Home,
  portfolio: Building2, properties: Building2,
  units: Layers, leases: KeyRound, tenants: Users, owners: User,
  cards: FileText, operations: Wrench, accounting: Calculator, marketing: TrendingUp,
  data: Database, analytics: PieChart, ai: Zap, work: Folder, legal: FileText,
  settings: Settings, tools: Wrench, probe: Wrench
};

function pickIcon(label: string){
  const k = label.toLowerCase().replace(/\s+/g, "");
  return iconMap[k] || Folder;
}

export default function Sidebar(){
  const [loc] = useLocation();

  // collapsed state
  const [isCollapsed, setCollapsed] = useState<boolean>(() => {
    try { return localStorage.getItem("nav:collapsed") === "1"; } catch { return false; }
  });
  useEffect(() => { try { localStorage.setItem("nav:collapsed", isCollapsed ? "1" : "0"); } catch {} }, [isCollapsed]);

  // open groups per section
  const [openGroups, setOpenGroups] = useState<Record<string, boolean>>(() => {
    try { return JSON.parse(localStorage.getItem("nav:openGroups") || "{}"); } catch { return {}; }
  });
  useEffect(() => { try { localStorage.setItem("nav:openGroups", JSON.stringify(openGroups)); } catch {} }, [openGroups]);

  const toggleGroup = (sec: string, grp: string) => {
    setOpenGroups((s) => ({ ...s, [`${sec}/${grp}`]: !s[`${sec}/${grp}`] }));
  };
  const isOpen = (sec: string, grp: string) => !!openGroups[`${sec}/${grp}`];

  return (
    <aside className={`sidebar ${isCollapsed ? "collapsed" : ""}`}>
      <div className="brand">
        <div className="logo"><img src="/logo.png" alt="Altus" /></div>
        <div className="title">Empire Command Center</div>
        <button className="pinBtn" onClick={() => setCollapsed(!isCollapsed)} title={isCollapsed ? "Unpin" : "Pin"}>
          {isCollapsed ? "»" : "«"}
        </button>
      </div>

      <nav className="nav">
        {NAV.map((section: Section) => (
          <div className="section" key={section.label}>
            <div className="group-label">{section.label}</div>
            {section.groups.map((group: Group) => {
              const hasItems = group.items && group.items.length > 0;
              const open = isOpen(section.label, group.label);
              return (
                <div className="group" key={`${section.label}/${group.label}`}>
                  <button className="group-row" onClick={() => hasItems && toggleGroup(section.label, group.label)}>
                    {React.createElement(pickIcon(group.label), { size: 16, className: "icon" })}
                    <span className="lbl">{group.label}</span>
                    {hasItems ? (
                      <span className="expand">
                        {open ? <ChevronDown size={14}/> : <ChevronRight size={14}/>}
                      </span>
                    ) : null}
                  </button>
                  {hasItems && open && (
                    <div className="leafList">
                      {group.items.map((leaf: Leaf) => {
                        const active = loc === leaf.path;
                        return (
                          <Link key={leaf.label + leaf.path} href={leaf.path}>
                            <a className={`leaf ${active ? "active" : ""}`} aria-current={active ? "page" : undefined}>
                              {React.createElement(pickIcon(leaf.label), { size: 14, className: "icon" })}
                              <span className="lbl">{leaf.label}</span>
                            </a>
                          </Link>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ))}
      </nav>

      <div className="sidebar-footer">
        <button className="pinBtn" onClick={() => setCollapsed(!isCollapsed)}>{isCollapsed ? "Unpin" : "Pin"}</button>
      </div>
    </aside>
  );
}
