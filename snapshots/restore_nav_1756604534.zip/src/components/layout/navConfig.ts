/**
 * Canonical Navigation — single source of truth.
 * Keep routes in sync with src/App.tsx.
 */
export type NavItem = { label: string; path: string; icon?: string };
export type NavSection = { title: string; items: NavItem[] };

const NAV: NavSection[] = [
  {
    title: "Dashboard",
    items: [
      { label: "Home", path: "/dashboard", icon: "🏠" },
    ],
  },
  {
    title: "Portfolio V3",
    items: [
      { label: "Properties", path: "/portfolio/properties", icon: "🏢" },
      { label: "Units",      path: "/portfolio/units",      icon: "📦" },
      { label: "Leases",     path: "/portfolio/leases",     icon: "📝" },
      { label: "Tenants",    path: "/portfolio/tenants",    icon: "👥" },
      { label: "Owners",     path: "/portfolio/owners",     icon: "👤" },
    ],
  },
  {
    title: "Tools",
    items: [
      { label: "Probe", path: "/tools/probe", icon: "🧪" },
    ],
  },
];

export default NAV;
