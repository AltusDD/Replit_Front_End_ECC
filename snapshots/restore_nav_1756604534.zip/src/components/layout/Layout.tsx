import React from "react";
import Nav from "./Nav";

export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="layout">
      <Nav />
      <main className="main">{children}</main>
    </div>
  );
}
