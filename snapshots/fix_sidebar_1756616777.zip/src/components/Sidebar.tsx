/* eslint-disable */
import React, { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import NAVCFG from "@/components/layout/navConfig";

/** Normalize whatever shape navConfig exports into {label, groups:[{label, items:[{label, path}]}]} */
type Leaf = { label: string; path: string };
type Group = { label: string; items: Leaf[] };
type Section = { label: string; groups: Group[] };

function normalizeNav(raw: any): Section[] {
  const arr = Array.isArray(raw) ? raw : [];
  return arr.map((sec: any) => {
    const sLabel = sec.label || sec.title || "";
    let groups: Group[] = [];

    if (Array.isArray(sec.groups) && sec.groups.length) {
      groups = sec.groups.map((g: any) => ({
        label: g.label || g.title || "",
        items: (Array.isArray(g.items) ? g.items : []).map((it: any) => ({
          label: it.label || it.title || it.name || "",
          path: it.path || it.href || it.to || it.url || "",
        })),
      }));
    } else if (Array.isArray(sec.items) && sec.items.length) {
      groups = [
        {
          label: sLabel,
          items: sec.items.map((it: any) => ({
            label: it.label || it.title || it.name || "",
            path: it.path || it.href || it.to || it.url || "",
          })),
        },
      ];
    } else {
      groups = [];
    }

    return { label: sLabel, groups };
  });
}

const SECTIONS: Section[] = normalizeNav(NAVCFG);

export default function Sidebar() {
  const [loc] = useLocation(); // wouter location
  const [collapsed, setCollapsed] = useState<boolean>(() => {
    try { return localStorage.getItem("nav:collapsed")==="1"; } catch { return false; }
  });
  useEffect(()=>{ try { localStorage.setItem("nav:collapsed", collapsed?"1":"0"); } catch {} },[collapsed]);

  // open/closed group state (persisted)
  const [open, setOpen] = useState<Record<string, boolean>>(() => {
    try { return JSON.parse(localStorage.getItem("nav:open")||"{}"); } catch { return {}; }
  });
  useEffect(()=>{ try { localStorage.setItem("nav:open", JSON.stringify(open)); } catch {} },[open]);
  const toggle = (k:string) => setOpen(s => ({...s, [k]: !s[k]}));

  const isLeafActive = (p: string) => (!!p && (loc === p || loc.startsWith(p + "/")));

  return (
    <aside className={`sidebar ${collapsed ? "collapsed" : ""}`} data-role="sidebar">
      {/* Brand */}
      <div className="brand">
        <img className="brand-logo" src="/logo.png" alt="" />
        <button className="pinBtn" onClick={()=>setCollapsed(!collapsed)}>
          {collapsed ? "»" : "«"}
        </button>
      </div>

      {/* Independent scroll area */}
      <div className="sidebar-scroll">
        <div data-nav>
          {SECTIONS.map((section) => (
            <div className="section" key={section.label || Math.random()}>
              {section.label ? <div className="section-title">{section.label}</div> : null}

              {section.groups.map((g) => {
                const key = (section.label||"") + "/" + (g.label||"");
                const hasChildren = g.items && g.items.length > 0;
                const groupHasActiveChild = hasChildren && g.items.some((it)=> isLeafActive(it.path));
                const isOpen = !!open[key];
                const showChildren = hasChildren && (isOpen || (collapsed && groupHasActiveChild));

                return (
                  <div className="group" key={key}>
                    <button
                      className="group-row"
                      onClick={()=> hasChildren && toggle(key)}
                      aria-expanded={hasChildren ? String(isOpen) : undefined}
                      data-current-child={groupHasActiveChild ? "true" : undefined}
                      type="button"
                    >
                      <span className="icon" aria-hidden="true" />
                      <span className="lbl">{g.label}</span>
                      {hasChildren ? <span className="expand" aria-hidden="true">▾</span> : <span />}
                    </button>

                    {/* children */}
                    {hasChildren && (
                      <ul className="leafList" style={{ display: showChildren ? "flex" : undefined, flexDirection: "column", gap: 4 }}>
                        {g.items.map((leaf) => {
                          const active = isLeafActive(leaf.path);
                          return (
                            <li key={leaf.path || leaf.label}>
                              <Link href={leaf.path || "#"}>
                                <a className={`leaf ${active ? "active" : ""}`} aria-current={active ? "page" : undefined}>
                                  <span className="icon" aria-hidden="true" />
                                  <span className="lbl">{leaf.label}</span>
                                </a>
                              </Link>
                            </li>
                          );
                        })}
                      </ul>
                    )}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>

      {/* Footer */}
      <div className="sidebar-footer">
        {!collapsed && (
          <button className="pinBtn" onClick={()=>setCollapsed(!collapsed)}>
            {collapsed ? "Unpin" : "Pin"}
          </button>
        )}
      </div>
    </aside>
  );
}
