const fs = require('fs')
const path = require('path')
const bad = []

function walk(dir) {
  for (const name of fs.readdirSync(dir)) {
    if (name === 'node_modules' || name.startsWith('.')) continue
    const p = path.join(dir, name)
    const st = fs.statSync(p)
    if (st.isDirectory()) walk(p)
    else if (/\.(tsx?|jsx?)$/.test(name)) {
      const src = fs.readFileSync(p, 'utf8')
      if (/fetch\(['"`]\/api/.test(src) || /new URL\(['"`]\/api/.test(src)) {
        bad.push([p, 'Hardcoded /api (use @lib/ecc-api buildUrl)'])
      }
      if (/from ['"]\/src\/lib\/ecc-api['"]/.test(src) || /from ['"]@\/lib\/ecc-api\.ts['"]/.test(src)) {
        bad.push([p, 'Wrong client import path (use @lib/ecc-api)'])
      }
    }
  }
}

const srcDir = path.join(process.cwd(), 'src')
if (fs.existsSync(srcDir)) walk(srcDir)
if (bad.length) {
  console.error('❌ VET FAILED:\\n' + bad.map(([p,m]) => ` - ${p}: ${m}`).join('\\n'))
  process.exit(1)
}
console.log('✅ Vet passed.')
