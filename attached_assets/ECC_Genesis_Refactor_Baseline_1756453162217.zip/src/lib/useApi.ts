import { useEffect, useState } from 'react'
import { fetchCollection, fetchJSON } from '@lib/ecc-api'

export function useCollection(path: string, params?: any) {
  const [items, setItems] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<Error | null>(null)

  useEffect(() => {
    const ac = new AbortController()
    setLoading(true); setError(null)
    fetchCollection(path, { ...(params||{}), signal: ac.signal })
      .then(({ items }) => { if (!ac.signal.aborted) setItems(items) })
      .catch(e => { if (e?.name !== 'AbortError' && !ac.signal.aborted) setError(e as Error) })
      .finally(() => { if (!ac.signal.aborted) setLoading(false) })
    return () => ac.abort()
  }, [path, JSON.stringify(params||{})])

  return { items, loading, error }
}

export function useJSON(path: string, params?: any) {
  const [data, setData] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<Error | null>(null)
  useEffect(() => {
    const ac = new AbortController()
    setLoading(true); setError(null)
    fetchJSON(path, { params, signal: ac.signal })
      .then((d) => { if (!ac.signal.aborted) setData(d) })
      .catch(e => { if (e?.name !== 'AbortError' && !ac.signal.aborted) setError(e as Error) })
      .finally(() => { if (!ac.signal.aborted) setLoading(false) })
    return () => ac.abort()
  }, [path, JSON.stringify(params||{})])
  return { data, loading, error }
}
