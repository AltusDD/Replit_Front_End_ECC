export function asArray<T>(v: T | T[] | null | undefined): T[] {
  if (v == null) return []
  return Array.isArray(v) ? v : [v]
}

export function pick<T extends Record<string, any>>(obj: T, ...keys: string[]): any {
  for (const k of keys) if (obj && obj[k] != null && obj[k] !== '') return obj[k]
  return ''
}

export function safeNum(v: any, d = 0): number {
  const n = Number(v)
  return Number.isFinite(n) ? n : d
}
