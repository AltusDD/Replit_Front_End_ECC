export { buildUrl, fetchJSON, fetchCollection, getBase } from './ecc-api'
export const fetchPortfolio = fetchCollection
