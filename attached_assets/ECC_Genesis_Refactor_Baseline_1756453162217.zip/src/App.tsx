import React from 'react'
import { Routes, Route, NavLink } from 'react-router-dom'
import Dashboard from '@/pages/dashboard'
import Properties from '@/pages/portfolio/properties'
import Units from '@/pages/portfolio/units'
import Leases from '@/pages/portfolio/leases'
import Tenants from '@/pages/portfolio/tenants'
import Owners from '@/pages/portfolio/owners'
import ApiProbe from '@/pages/tools/ApiProbe'
import ErrorBoundary from '@/components/ErrorBoundary'

export default function App() {
  return (
    <div className="app">
      <aside className="sidebar">
        <nav>
          <NavLink to="/" end>
            Dashboard
          </NavLink>
          <div style={{ padding: '8px 14px', opacity: 0.7, fontSize: 12 }}>Portfolio V3</div>
          <NavLink to="/portfolio/properties">Properties</NavLink>
          <NavLink to="/portfolio/units">Units</NavLink>
          <NavLink to="/portfolio/leases">Leases</NavLink>
          <NavLink to="/portfolio/tenants">Tenants</NavLink>
          <NavLink to="/portfolio/owners">Owners</NavLink>
          <div style={{ padding: '8px 14px', opacity: 0.7, fontSize: 12 }}>Tools</div>
          <NavLink to="/tools/probe">API Probe</NavLink>
        </nav>
      </aside>
      <main className="main">
        <ErrorBoundary>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/portfolio/properties" element={<Properties />} />
            <Route path="/portfolio/units" element={<Units />} />
            <Route path="/portfolio/leases" element={<Leases />} />
            <Route path="/portfolio/tenants" element={<Tenants />} />
            <Route path="/portfolio/owners" element={<Owners />} />
            <Route path="/tools/probe" element={<ApiProbe />} />
          </Routes>
        </ErrorBoundary>
      </main>
    </div>
  )
}
