import React from 'react'

type Tone = 'neutral' | 'info' | 'success' | 'warn' | 'danger'

const toneMap: Record<Tone, React.CSSProperties> = {
  neutral: { background: 'var(--surface)', color: 'var(--fg)', border: '1px solid var(--border-1)' },
  info: { background: 'rgba(247,201,72,0.08)', color: 'var(--gold)', border: '1px solid var(--border-1)' },
  success: { background: 'rgba(50,210,150,0.08)', color: 'var(--success)', border: '1px solid var(--border-1)' },
  warn: { background: 'rgba(247,201,72,0.08)', color: 'var(--gold)', border: '1px solid var(--border-1)' },
  danger: { background: 'rgba(229,72,77,0.08)', color: 'var(--danger)', border: '1px solid var(--border-1)' }
}

export default function Badge({ tone='neutral', children }: { tone?: Tone; children: React.ReactNode }) {
  return <span style={{ ...toneMap[tone], borderRadius: 999, padding: '2px 8px', fontSize: 12 }}>{children}</span>
}
