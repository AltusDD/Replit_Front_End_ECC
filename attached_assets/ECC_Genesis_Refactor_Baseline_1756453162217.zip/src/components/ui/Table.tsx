import React from 'react'

export type Column<T> = { key: keyof T | string; header: string; width?: string | number; render?: (row: T) => React.ReactNode }

export default function Table<T extends Record<string, any>>({ columns, rows, empty='No data.' }:
  { columns: Column<T>[]; rows: T[]; empty?: string }) {
  return (
    <div className="panel">
      <table style={{ width:'100%', borderCollapse:'collapse' }}>
        <thead>
          <tr>
            {columns.map((c, i) => (
              <th key={i} style={{ textAlign:'left', padding:'8px', borderBottom:'1px solid var(--border-1)' }}>{c.header}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.length === 0 ? (
            <tr><td colSpan={columns.length} style={{ padding:'10px', opacity:0.7 }}>{empty}</td></tr>
          ) : rows.map((row, ri) => (
            <tr key={ri} style={{ borderBottom:'1px solid var(--border-1)' }}>
              {columns.map((c, ci) => (
                <td key={ci} style={{ padding:'8px' }}>{c.render ? c.render(row) : String(row[c.key as string] ?? '')}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
