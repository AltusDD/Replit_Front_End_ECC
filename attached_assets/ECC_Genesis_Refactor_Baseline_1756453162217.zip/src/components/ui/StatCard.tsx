import React from 'react'
import Badge from './Badge'

type Props = {
  title: string
  value: React.ReactNode
  trend?: React.ReactNode
  badge?: { tone?: 'neutral'|'info'|'success'|'warn'|'danger'; label: string }
}

export default function StatCard({ title, value, trend, badge }: Props) {
  return (
    <div className="panel">
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <div style={{ opacity:0.8, fontSize:12 }}>{title}</div>
        {badge && <Badge tone={badge.tone || 'neutral'}>{badge.label}</Badge>}
      </div>
      <div style={{ fontSize:28, fontWeight:600, marginTop:8 }}>{value}</div>
      {trend && <div style={{ marginTop:6, opacity:0.8, fontSize:12 }}>{trend}</div>}
    </div>
  )
}
