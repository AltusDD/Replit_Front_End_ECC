import React from 'react'
import { fetchJSON } from '@lib/ecc-api'
import Badge from '@/components/ui/Badge'

type Check = {
  label: string
  path: string
  status?: number
  ok?: boolean
  note?: string
}

const v3 = ['properties', 'units', 'leases', 'tenants', 'owners']

export default function ApiProbe() {
  const [rows, setRows] = React.useState<Check[]>([])
  const [busy, setBusy] = React.useState(false)

  async function run() {
    setBusy(true)
    const checks: Check[] = [
      { label: 'Health', path: 'health' },
      ...v3.map(e => ({ label: `V3 ${e}?limit=1`, path: `portfolio/${e}` }))
    ]
    const out: Check[] = []
    for (const c of checks) {
      try {
        const url = c.path === 'health' ? 'health' : `${c.path}`
        const data = await fetchJSON(url, { params: c.path === 'health' ? undefined : { limit: 1 } })
        out.push({ ...c, status: 200, ok: true, note: Array.isArray(data) ? JSON.stringify(data[0]||{}) : JSON.stringify(data).slice(0, 200) })
      } catch (e: any) {
        const msg = String(e?.message || e)
        const status = Number((/HTTP\s+(\d+)/.exec(msg)||[])[1] || 0)
        out.push({ ...c, status, ok: false, note: msg })
      }
    }
    setRows(out); setBusy(false)
  }

  React.useEffect(() => { run() }, [])

  return (
    <div className="panel">
      <h3>API Probe (V3)</h3>
      <p>Checks /api/health and /api/portfolio/* endpoints. RPC is intentionally not tested here.</p>
      <button onClick={run} disabled={busy} style={{ padding:'6px 10px', borderRadius:8 }}>Run</button>
      <div style={{ marginTop:12 }}>
        {rows.map((r, i) => (
          <div key={i} style={{ display:'flex', gap:12, alignItems:'center', padding:'8px 0', borderBottom:'1px solid var(--border-1)' }}>
            <div style={{ width: 180 }}>{r.label}</div>
            <Badge tone={r.ok ? 'success' : 'danger'}>{r.ok ? '✅ 200' : `❌ ${r.status||''}`}</Badge>
            <code style={{ opacity:0.8 }}>{r.path}</code>
            <div style={{ opacity:0.7, fontSize:12, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{r.note}</div>
          </div>
        ))}
      </div>
    </div>
  )
}
