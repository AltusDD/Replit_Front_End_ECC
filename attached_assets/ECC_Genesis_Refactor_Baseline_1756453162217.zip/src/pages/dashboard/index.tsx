import React from 'react'
import StatCard from '@/components/ui/StatCard'
import Badge from '@/components/ui/Badge'
import { useCollection, useJSON } from '@lib/useApi'

function Count({ entity }: { entity: string }) {
  const { items, loading, error } = useCollection(entity, { limit: 1 })
  if (error) return <StatCard title={entity} value={'—'} badge={{ tone:'danger', label:'Error' }} />
  return <StatCard title={entity} value={loading ? '…' : String(items.length > -1 ? 'live' : '—')} trend={`${loading ? 'Loading' : 'V3 online'}`} />
}

export default function Dashboard() {
  // Optional RPC metrics (safe to 404)
  const rpcKeys = ['dashboard_growth','dashboard_ops','dashboard_financials','dashboard_kpis','next_actions']
  const rpc = rpcKeys.map(k => ({ k, ...useJSON(`rpc/${k}`) }))

  return (
    <div style={{ display:'grid', gap:12 }}>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(5, minmax(180px, 1fr))', gap:12 }}>
        <Count entity="properties" />
        <Count entity="units" />
        <Count entity="leases" />
        <Count entity="tenants" />
        <Count entity="owners" />
      </div>

      <div className="panel">
        <h3>Optional RPC Metrics</h3>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(3, minmax(220px, 1fr))', gap:12 }}>
          {rpc.map(({ k, data, loading, error }) => (
            <StatCard
              key={k}
              title={k}
              value={error ? '—' : loading ? '…' : (Array.isArray(data) ? data.length : Object.keys(data||{}).length)}
              badge={error ? { tone:'warn', label:'Not available yet' } : undefined}
              trend={!error ? 'Live' : 'RPC optional'}
            />
          ))}
        </div>
        <p style={{ opacity:0.75, marginTop:8 }}>
          RPC endpoints are optional; 404s are expected until backends expose them.
        </p>
      </div>
    </div>
  )
}
