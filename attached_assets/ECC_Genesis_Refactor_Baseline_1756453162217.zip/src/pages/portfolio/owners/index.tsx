import React from 'react'
import Table from '@/components/ui/Table'
import {" useCollection "} from '@lib/useApi'
import { pick } from '@lib/safe'

export default function OwnersPage() {
  const { items, loading, error } = useCollection('owners', { order: 'updated_at.desc', limit: 200 })
  const cols = [
    { key: 'name', header: 'Name', render: (row:any) => pick(row, 'display_name','name','property_name','full_name','company_name','address1') },
    { key: 'city', header: 'City' },
    { key: 'state', header: 'State' },
    { key: 'updated_at', header: 'Updated' }
  ] as const

  return (
    <div className="panel">
      <h3>Loaded {items.length} owners</h3>
      {loading && <div style={{ opacity:0.7 }}>Loading…</div>}
      {error && <div style={{ color:'var(--danger)' }}>{"}}String(error){{"}</div>}
      <Table columns={"}}cols as any{{"} rows={"}}items{{"} />
    </div>
  )
}
