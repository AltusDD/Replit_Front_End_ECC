import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'node:path'

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
      '@lib': path.resolve(__dirname, './src/lib')
    }
  },
  server: {
    host: '0.0.0.0',
    port: 5173,
    strictPort: true,
    allowedHosts: [process.env.VITE_ALLOWED_HOST || 'localhost'],
    proxy: {
      '/api': {
        target: 'https://empirecommandcenter-altus-staging.azurewebsites.net',
        changeOrigin: true,
        secure: true
      }
    }
  }
})
