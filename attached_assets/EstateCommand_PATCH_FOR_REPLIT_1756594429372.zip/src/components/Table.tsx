import React from 'react';

const Table = ({ columns, data, onRowDoubleClick }) => {
  return (
    <div className="table-wrapper">
      <table className="enhanced-table">
        <thead>
          <tr>
            {columns.map((col, index) => (
              <th key={index} className="table-header">{col.header}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.map((row, rowIndex) => (
            <tr
              key={rowIndex}
              className="table-row"
              onDoubleClick={() => onRowDoubleClick(row)}
            >
              {columns.map((col, colIndex) => (
                <td key={colIndex}>{row[col.accessor]}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Table;
