
import React from 'react';

export default function Table() {
  return <div className="table-wrapper">Table goes here</div>;
}
