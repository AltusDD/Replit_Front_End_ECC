import React from 'react';
import CollectionPage from '../_Collection';
export default function Page() { return <CollectionPage name="leases" /> }
